export default function PrintStream () {}
