export default function OutputStream () {}
