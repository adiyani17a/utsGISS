export default function InputStream () {}
