export default function LineNumberReader () {}
