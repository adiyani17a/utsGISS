export default function IllegalArgumentException (message) {
  this.message = message
}
