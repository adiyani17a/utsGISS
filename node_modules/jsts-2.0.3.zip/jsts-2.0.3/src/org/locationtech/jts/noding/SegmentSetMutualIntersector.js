export default class SegmentSetMutualIntersector {
	constructor() {
		SegmentSetMutualIntersector.constructor_.apply(this, arguments);
	}
	process(segStrings, segInt) {}
	getClass() {
		return SegmentSetMutualIntersector;
	}
	get interfaces_() {
		return [];
	}
}
SegmentSetMutualIntersector.constructor_ = function () {};
