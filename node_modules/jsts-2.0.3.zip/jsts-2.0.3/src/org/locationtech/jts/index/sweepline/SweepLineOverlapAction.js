export default class SweepLineOverlapAction {
	constructor() {
		SweepLineOverlapAction.constructor_.apply(this, arguments);
	}
	overlap(s0, s1) {}
	getClass() {
		return SweepLineOverlapAction;
	}
	get interfaces_() {
		return [];
	}
}
SweepLineOverlapAction.constructor_ = function () {};
