import * as kdtree from './index/kdtree'
import * as quadtree from './index/quadtree'
import * as strtree from './index/strtree'

export { kdtree, quadtree, strtree }
